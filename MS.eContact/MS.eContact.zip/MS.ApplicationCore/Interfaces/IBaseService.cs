﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MS.ApplicationCore.Interfaces
{
    public interface IBaseService<TEntity>:IAsyncService<TEntity>
    {
        
    }
}
