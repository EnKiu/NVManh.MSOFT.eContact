﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MS.ApplicationCore.Utilities
{
    public static class CommonFunction
    {
        private readonly static IHttpContextAccessor _httpContextAccessor;

    }
}
