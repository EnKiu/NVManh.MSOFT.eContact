﻿var Entity = {
    Customer: {

    },
}