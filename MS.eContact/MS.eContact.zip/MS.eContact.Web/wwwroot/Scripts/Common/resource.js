﻿var Resource = {
    Gender_Female: "Nữ",
    Gender_Male: "Nam",

}